package com.kopapirollo;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private int playerScore = 0;
    private int computerScore = 0;

    private TextView resultsTextView;
    private ImageView playerImageView;
    private ImageView computerImageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        resultsTextView = findViewById(R.id.resultsTextView);
        playerImageView = findViewById(R.id.playerImageView);
        computerImageView = findViewById(R.id.computerImageView);

        Button buttonRock = findViewById(R.id.buttonRock);
        Button buttonPaper = findViewById(R.id.buttonPaper);
        Button buttonScissors = findViewById(R.id.buttonScissors);

        buttonRock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                playGame("rock");
            }
        });

        buttonPaper.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                playGame("paper");
            }
        });

        buttonScissors.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                playGame("scissors");
            }
        });
    }

    private void playGame(String playerChoice) {
        String computerChoice = getComputerChoice();
        updateImages(playerChoice, computerChoice);
        String result = getResult(playerChoice, computerChoice);

        if (result.equals("player")) {
            playerScore++;
            Toast.makeText(this, "Te nyertél!", Toast.LENGTH_SHORT).show();
        } else if (result.equals("computer")) {
            computerScore++;
            Toast.makeText(this, "A számítógép nyert!", Toast.LENGTH_SHORT).show();
        }

        updateResultsText();
    }

    private String getComputerChoice() {
        String[] choices = {"rock", "paper", "scissors"};
        Random random = new Random();
        return choices[random.nextInt(choices.length)];
    }

    private void updateImages(String playerChoice, String computerChoice) {
        int playerImageResId = playerChoice.equals("rock") ? R.drawable.rock :
                playerChoice.equals("paper") ? R.drawable.paper :
                        R.drawable.scissors;
        int computerImageResId = computerChoice.equals("rock") ? R.drawable.rock :
                computerChoice.equals("paper") ? R.drawable.paper :
                        R.drawable.scissors;

        playerImageView.setImageResource(playerImageResId);
        computerImageView.setImageResource(computerImageResId);
    }

    private String getResult(String playerChoice, String computerChoice) {
        if (playerChoice.equals(computerChoice)) {
            return "draw";
        }
        if ((playerChoice.equals("rock") && computerChoice.equals("scissors")) ||
                (playerChoice.equals("paper") && computerChoice.equals("rock")) ||
                (playerChoice.equals("scissors") && computerChoice.equals("paper"))) {
            return "player";
        }
        return "computer";
    }

    private void updateResultsText() {
        resultsTextView.setText("Eredmény: Te " + playerScore + " - Számítógép " + computerScore);
    }
}
